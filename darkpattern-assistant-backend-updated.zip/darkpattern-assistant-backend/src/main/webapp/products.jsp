<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recently Analyzed | DarkPattern Assistant</title>
  <link rel="icon" href='data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">🛡️</text></svg>'>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<nav class="navbar">
<a href="index.jsp" class="logo">🛡️ DarkPattern Assistant</a>
<button class="menu-toggle" id="menuToggle" aria-label="Menu">
<span></span><span></span><span></span>
</button>
    <ul id="navLinks">
      <li><a href="index.jsp">Home</a></li>
      <li><a href="products">Products</a></li>
      <li><a href="about.jsp">About</a></li>
      <li><a href="faq.jsp">FAQ</a></li>
      <li><a href="contact.jsp">Contact</a></li>
      <li><a href="blog.jsp">Blog</a></li>
      <li><a href="history">My History</a></li>
      <li><a href="login.jsp">Login</a></li>
      <li><a href="signup.jsp">Sign Up</a></li>
      <button class="theme-toggle" id="themeToggle" aria-label="Toggle dark mode">🌙</button>
    </ul>
  </nav>

  <section class="section">
    <h2 class="section-title">Recently Analyzed Products</h2>
    <p class="section-sub">See what our community has checked so far.</p>
    <div class="filter-bar">
       <input type="text" id="searchInput" placeholder="Search products...">
       <select id="riskFilter">
          <option value="all">All Risk Levels</option>
          <option value="risk-low">Low Risk</option>
          <option value="risk-medium">Moderate Risk</option>
          <option value="risk-high">High Risk</option>
       </select>
    </div>

    <div class="product-grid">
    <c:choose>
    <c:when test="${not empty recentProducts}">
    <c:forEach var="prod" items="${recentProducts}">
    <a href="result.jsp?id=${prod.id}" class="product-card">
    <div class="product-score risk-${prod.riskLevel}"> ${prod.score}% </div>
    <h3>${prod.name}</h3>
              <p class="product-url">${prod.url}</p>
              <span class="product-risk-label">${prod.riskLabel}</span>
            </a>
          </c:forEach>
        </c:when>
        <c:otherwise>
          <a href="result.jsp" class="product-card">
            <div class="product-score risk-high">82%</div>
            <h3>Wireless Earbuds X200</h3>
            <p class="product-url">example-store.com</p>
            <span class="product-risk-label">High Risk</span>
          </a>
          <a href="result.jsp" class="product-card">
            <div class="product-score risk-medium">55%</div>
            <h3>Smart Fitness Band</h3>
            <p class="product-url">shopfast.in</p>
            <span class="product-risk-label">Moderate Risk</span>
          </a>
          <a href="result.jsp" class="product-card">
            <div class="product-score risk-low">18%</div>
            <h3>Ceramic Cookware Set</h3>
            <p class="product-url">homeessentials.com</p>
            <span class="product-risk-label">Low Risk</span>
          </a>
          <a href="result.jsp" class="product-card">
            <div class="product-score risk-high">90%</div>
            <h3>Premium Backpack</h3>
            <p class="product-url">trendybags.co</p>
            <span class="product-risk-label">High Risk</span>
          </a>
        </c:otherwise>
      </c:choose>
    </div>

    <div class="result-actions">
      <a href="index.jsp" class="btn">Analyze Your Own Product</a>
    </div>
  </section>

  <footer class="footer">
    <p>© 2026 Code Breakers | E-Commerce Transparency Assistant</p>
  </footer>

  <script src="${pageContext.request.contextPath}/js/script.js"></script>
  <button class="back-to-top" id="backToTop">↑</button>
</body>
</html>