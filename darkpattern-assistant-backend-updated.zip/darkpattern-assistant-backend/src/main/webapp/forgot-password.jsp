<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reset Password | DarkPattern Assistant</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <nav class="navbar">
    <a href="index.jsp" class="logo">🛡️ DarkPattern Assistant</a>
    <ul id="navLinks"><li><a href="index.jsp">Home</a></li><li><a href="login.jsp">Login</a></li><li><a href="signup.jsp">Sign Up</a></li></ul>
  </nav>
  <div class="auth-wrapper">
    <div class="auth-card">
      <h2>Reset Password</h2>
      <p>Enter the email address registered with your account and choose a new password.</p>
      <c:if test="${not empty param.msg}"><div class="alert" role="alert"><c:out value="${param.msg}"/></div></c:if>
      <form action="reset-password" method="post">
        <input id="email" type="email" name="email" placeholder="Email" autocomplete="email" required>

        <input id="newPassword" type="password" name="newPassword" placeholder="New password (min 6 characters)" minlength="6" autocomplete="new-password" required>

        <input id="confirmPassword" type="password" name="confirmPassword" placeholder="Confirm new password" minlength="6" autocomplete="new-password" required>

        <button type="submit" class="btn">Reset Password</button>
      </form>
      <p class="switch"><a href="login.jsp">Back to login</a></p>
      <p class="small-note">Demo limitation: this reset flow uses email only. Production applications should verify ownership using a time-limited email reset link.</p>
    </div>
  </div>
</body>
</html>
