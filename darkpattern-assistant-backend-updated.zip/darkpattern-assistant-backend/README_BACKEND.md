# DarkPattern Assistant — Backend + Frontend

This project adds Java Servlet backend routes to the JSP frontend supplied by the team. It uses Maven, Jakarta Servlets/JSP/JSTL, Java 17+, MySQL 8, and Tomcat 10.1+ (Tomcat 11 recommended).

## Included routes
- `POST /analyze` — accepts `productUrl`, fetches a public HTTP/HTTPS page, runs keyword-based heuristic checks, calculates score and persists result.
- `POST /signup` — accepts `fullName`, `email`, `password`, `confirmPassword`.
- `POST /login` — accepts `email`, `password`; session login.
- `GET /logout` — invalidates session.
- `POST /contact` — saves feedback.
- `GET /history` — login-protected history for the current user.
- `GET /products` — recent analyses list.
- Existing JSP routes and static assets remain in place.

## 1. Requirements
Install JDK 17 or newer, Maven 3.9+, MySQL 8+, and Tomcat 10.1+ / 11. Make sure `java -version`, `mvn -version`, and MySQL service work in CMD.

## 2. Create database
Open MySQL Workbench, open `database/schema.sql`, and execute the whole file. Or from CMD:
`mysql -u root -p < database/schema.sql`

Default connection assumes MySQL at localhost:3306, database `darkpattern_assistant`, user `root`, blank password. Configure credentials using environment variables before starting Tomcat:
- `DPA_DB_URL` (optional; default URL shown in `DB.java`)
- `DPA_DB_USER` (default `root`)
- `DPA_DB_PASSWORD` (default blank)

Windows CMD example (replace password):
```
set DPA_DB_USER=root
set DPA_DB_PASSWORD=your_mysql_password
```
Set these in the same CMD environment used to start Tomcat. Do not commit real credentials.

## 3. Build WAR
From CMD:
```
cd C:\path\to\darkpattern-assistant-backend
mvn clean package
```
Expected output: `BUILD SUCCESS`; WAR at `target\darkpattern-assistant.war`.

## 4. Deploy
Copy `target\darkpattern-assistant.war` to Tomcat's `webapps` folder. Start Tomcat using `bin\startup.bat`, then open:
`http://localhost:8080/darkpattern-assistant/`

If Tomcat is already running, stop it first, replace the WAR and expanded `webapps\darkpattern-assistant` folder, then start again. Use the same Tomcat installation you start.

## 5. Test in browser
1. Open homepage.
2. Sign up at `signup.jsp` with a new email and password of at least 6 characters.
3. Log in using the same email/password.
4. Submit a public product page URL in the homepage form. Result should show score and detected patterns.
5. Visit `/products` for recent analysis records.
6. Visit `/history` while logged in for your own analysis history.
7. Submit the contact form.
8. Log out using `/logout`.

Context path example: `http://localhost:8080/darkpattern-assistant/analyze`.

## Important behavior and limitations
- The PDF specifies a one-free-analysis-per-visitor session rule; after one successful anonymous analysis, further anonymous analysis attempts are redirected to login. Logged-in users can analyze repeatedly.
- The score formula follows the PDF: start at 100, deduct 20 for fake urgency, 20 misleading discount, 15 hidden charges, 10 confirm-shaming, 10 frequent price changes, 15 countdown never expires, minimum 0. Score maps to low risk 80–100, moderate 50–79, high 0–49.
- A single HTML fetch cannot prove that a countdown resets, that a price is historically inflated, or that stock claims are false. These are heuristic keyword flags and the result text explains the limitation. Many shopping sites block automated fetches or render product data with JavaScript; those URLs may fail or return incomplete HTML.
- History is account-specific. Anonymous analyses are stored with a NULL user ID and will not appear in a user's history.
- This is an educational project, not a guarantee that a product or seller is trustworthy.

## Password reset feature (added)
- Page: `forgot-password.jsp`
- Endpoint: `POST /reset-password`
- Form fields: `email`, `newPassword`, `confirmPassword`
- Validates that passwords match and are at least 6 characters.
- Looks up the account by email and updates `users.password_hash` using the existing `PasswordUtil.hash()` implementation (PBKDF2).
- Redirects back to the reset page with a message for validation/account errors; on success redirects to `login.jsp` with a success message.
- A “Forgot password?” link is available on `login.jsp`.

**Security warning:** this is an email-only reset flow as specified in the project note and is suitable only for a local/demo environment. It does not prove control of the email address. Before public deployment, replace it with a time-limited, single-use token sent to the user's email address, and rate-limit reset requests.
