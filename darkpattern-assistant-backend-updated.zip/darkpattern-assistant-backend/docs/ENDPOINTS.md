# Endpoint contract

| Method | Path | Form fields | Success |
|---|---|---|---|
| POST | `/analyze` | `productUrl` | forwards to `result.jsp` with productUrl, score, grade, riskLevel, riskLabel, scoreDescription, patterns |
| POST | `/signup` | `fullName`, `email`, `password`, `confirmPassword` | redirects to login |
| POST | `/login` | `email`, `password` | creates session, redirects home |
| GET | `/logout` | — | invalidates session |
| POST | `/contact` | `fullName`, `email`, `reason`, `message` | stores contact message |
| GET | `/history` | — | requires login; forwards `recentProducts` to history.jsp |
| GET | `/products` | — | forwards recent `recentProducts` to products.jsp |

`riskLevel` in result.jsp is passed as `risk-low`, `risk-medium`, or `risk-high`. The database stores `low`, `medium`, or `high`, which the products/history JSPs prefix with `risk-`.
